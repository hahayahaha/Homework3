var Bmob = require('utils/bmob.js');
Bmob.initialize("f516874191c8970b02d0cfa02fb87667", "1d2383af04d70a3fa900559986239120");
