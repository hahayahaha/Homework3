// about/about.js
var Bmob = require('../../utils/bmob.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    category:[
      {name:'科技',id:'keji'},
      {name:'文创',id:'wenchuang'},
      {name:'演出',id:'yanchu'},
      {name:'活动',id:'huodong'}
    ],
    pjlist:[
      {
        id:'keji',
        banner:'/images/keji.jpg',
        cate:'科技',
        crowdfundingprojects: [{
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }, {
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }]
      },
      {
        id: 'wenchuang',
        banner: '/images/wenchuang.jpg',
        cate: '文创',
        crowdfundingprojects: [{
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }, {
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }]
      },
      {
        id: 'yanchu',
        banner: '/images/yanchu.jpg',
        cate: '演出',
        crowdfundingprojects: [{
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }, {
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }]
      },
      {
        id: 'huodong',
        banner: '/images/huodong.jpg',
        cate: '活动',
        crowdfundingprojects: [{
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }, {
          name: "一株深山幽兰",
          comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
          imagePath: "/images/1.jpg",
          goalprice: "10000",
          ratio: "50"
        }]
      },
    ],
    curIndex: 0,
    isScroll: false,
    toView:'keji'
  },

  onLoad: function (options) {
    var _this = this;
    var Diary = Bmob.Object.extend("item");
    var query = new Bmob.Query(Diary);
    query.descending("createdAt");
    // 查询所有数据
    query.find({
      success: function (results) {
        _this.setData({
          result: results
        });
        console.log("共查询到 " + results.length + " 条记录");
      },

      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
  },

  
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  f1:function(event){
    var pjId = event.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/detail/detail?id=' +pjId
    })
  },
  switchTab(e){
    const self = this;
    this.setData({
      isScroll: true
    })
    setTimeout(function () {
      self.setData({
        toView: e.target.dataset.id,
        curIndex: e.target.dataset.index
      })
    }, 0)
    setTimeout(function () {
      self.setData({
        isScroll: false
      })
    }, 1)
  }
})