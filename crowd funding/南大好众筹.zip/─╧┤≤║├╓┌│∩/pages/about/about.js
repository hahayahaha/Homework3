// about/about.js
var Bmob = require('../../utils/bmob.js');
var ans = new Array();
Page({

  onLoad: function () {
    var _this=this;
    var Diary = Bmob.Object.extend("item");
    var query = new Bmob.Query(Diary);
    query.descending("createdAt");
    query.limit(10);
    // 查询所有数据
    query.find({
      success: function (results) {
        _this.setData({
          result:results
        });
        console.log("共查询到 " + results.length + " 条记录");
      },
      
      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
    var Diarya = Bmob.Object.extend("item");
    var queiry = new Bmob.Query(Diarya);
    queiry.ascending("createdAt");
    queiry.limit(3);
    // 查询所有数据
    queiry.find({
      success: function (resultso) {
        _this.setData({
          x: resultso
        });
        console.log("共查询到 " + resultso.length + " 条记录");
      },

      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
  },
  data: {
    imgUrls: [
      '/images/111.jpg',
      '/images/112.jpg',
      '/images/113.jpg'
    ],
    
  indicatorDots: false,
  autoplay: false,
  interval: 3000,
  duration: 800,
  },
  onShareAppMessage: function () {
  
  },
  f1: function (event) {
    var pjId = event.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/detail/detail?id=' + pjId
    })
  }
})