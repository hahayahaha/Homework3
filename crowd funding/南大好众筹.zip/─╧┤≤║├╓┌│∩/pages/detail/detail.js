// pages/detail/detail.js
var Bmob = require('../../utils/bmob.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    crowdfundingprojects: {
      name: "一株深山幽兰",
      backernum:"257",
      comment: "由于在大山里生活久了，对山里的一草一木皆感觉平常，同时也忽略了大山馈赠的宝藏。",
      imagePath: "/images/1.jpg",
      goalprice: "10000",
      finishedprice:"5000",
      ratio: "50",
      lable:"农业",
      details: "有女唤玥奴，幼年双亲皆逝。同年，其父兄将其过于门下，与膝下一女名子清者同养之。双姝自幼形影不离。经年后，子清已是婚嫁年岁，奈其自幼钟情道法，留意天地自然，便违其父命，出家修行。离前，清将佩玉赠予玥奴，以表其心意。来年初春，玥奴檐下小憩，无意将佩玉掉出，骤时，玉碎。经月过，得书知子清逝。因恸绝良久，同月亦卒。一鹤被兽夹所伤，亡矣。其偶徘徊于空数日，悲鸣阵阵，终亡。彼时有人叹之：憾哉？幸哉！",
      rewardsetting:[
        {
          backprice:5,
          reward:"精美礼品"
          },
        {
          backprice:20,
          reward:"高级礼品"
        }
          ],
    },
    curIndex:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this;
    var Diary = Bmob.Object.extend("item");
    var query = new Bmob.Query(Diary);
    query.descending("createdAt");
    // 查询所有数据
    query.find({
      success: function (results) {
        _this.setData({
          result: results
        });
        console.log("共查询到 " + results.length + " 条记录");
      },

      error: function (error) {
        console.log("查询失败: " + error.code + " " + error.message);
      }
    });
    console.log(options.id);
    this.setData({
      mid:options.id
    })
  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  bindTap(e) {
    const index = parseInt(e.currentTarget.dataset.index);
    this.setData({
      curIndex: index
    })
  }
})