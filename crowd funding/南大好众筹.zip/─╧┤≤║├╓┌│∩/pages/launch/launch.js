// pages/launch/launch.js
var Bmob = require('../../utils/bmob.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
      pjInformation:{
        xuehao:'',
        xingming:'',
        yuanxi:'',
        phone:'',
        pjmingcheng:'',
        pjjianjie:'',
        goalprice:'',
        pjdetails:'',
        reward:[{
          backmoney:'',
          rewarddetails:'',
        }, {
          backmoney: '',
          rewarddetails: '',
        }]
      }
  },
  onLoad() {
    var self = this;

    wx.getStorage({
      key: 'pjInformation',
      success: function (res) {
        self.setData({
          pjInformation: res.data
        })
      }
    })
  },
  formSubmit(e) {
    const value = e.detail.value;
    if (value.xuehao && value.xingming && value.yuanxi && value.phone && value.pjmingcheng && value.pjjianjie && value.goalprice && value.pjdetails && value.reward) {
      wx.setStorage({
        key: 'pjInformation',
        data: value,
        success() {
          wx.navigateBack();
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '请填写完整资料',
        showCancel: false
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})